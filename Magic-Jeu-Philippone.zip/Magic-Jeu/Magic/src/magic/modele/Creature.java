
package magic.modele;


public class Creature extends Carte implements Cloneable{

    public Creature(String nom, int cout, int att, int def, int fat) {
        this.setNom(nom);
        this.setCout(cout);
        this.setAtt(att);
        this.setDef(def);
        this.setFat(false);
        this.setVol(false);
        this.setRapide(false);
        this.setBonus(false);
        this.setEnchante(false);
        this.setTypeEnchantement(0);
    }
    
}
