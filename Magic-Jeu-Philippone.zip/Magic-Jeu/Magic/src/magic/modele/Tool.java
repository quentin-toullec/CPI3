
package magic.modele;


public class Tool {
    public static int monRandom(int min, int max)
    {
        return min + (int) (Math.random() * (max-min+1));
    }
    
}
