
package magic.main;

import magic.controleur.*;
import magic.modele.*;
import magic.vue.*;


public class RunMagic {

    
   public static void main(String[] args) throws InterruptedException, CloneNotSupportedException{
        
        Joueur j1 = new JoueurHumain(1, "Audrey");
        //Joueur j2= new JoueurAleatoireFacile(2, "Deep Blue");
        Joueur j2= new JoueurAleatoireDifficile(2, "Deep Blue");
        
        Jeu j= new Jeu(j1, j2);
        
        ControleurJeu controleur = new ControleurJeu(j);
        
        Vue vue = new Vue(controleur);
        j.addObserver(vue);     
        
        j.jouerPartie2();
        
    }
    
}
