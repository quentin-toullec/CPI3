
package magic.observeur;


public interface Observer {
    
    // passer les arguments inutiles à null
    public void update(int code, String s1, String s2, String s3, String s4, int x1, int y1, int x2, int y2);
    
}
