
package magic.observeur;


public interface Observable {
    
    public void addObserver(Observer obs);
    public void notifyObserver(int code, String s1, String s2, String s3, String s4, int x1, int y1, int x2, int y2);
    public void removeObserver();
}
